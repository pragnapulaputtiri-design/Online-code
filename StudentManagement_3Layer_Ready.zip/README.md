# Student Management System — 3 Layer Full Stack

## Stack
Frontend: HTML + CSS + JavaScript
Middle layer: Java Spring Boot + REST Controller + Service
Data access: Repository using JDBC
Database: MySQL
Security: Spring Security + BCrypt
Build: Maven

## Architecture
Browser
 -> REST Controller
 -> Service
 -> Repository/JDBC
 -> MySQL

## Requirements
- JDK 17+
- Maven 3.9+
- MySQL 8+

## One-time database setup
1. Start MySQL.
2. Run `database/database.sql`.
3. Default database credentials expected by the application:
   username: root
   password: root

If your local MySQL password is different, update the single password value in:
`backend/src/main/resources/application.properties`

That is environment configuration, not application-code changes.

## Run
From the `backend` directory:

mvn spring-boot:run

Open:
http://localhost:8080/

Demo:
Username: admin
Password: admin123

## Features
- Login
- Dashboard
- Add student
- View/search students
- Edit student
- Delete student
- BCrypt password hashing
- REST APIs
- JDBC repository
- Validation
- Error handling

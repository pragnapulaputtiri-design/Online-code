package com.example.student.controller;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/auth")
public class AuthController {
 private final AuthenticationManager manager;
 public AuthController(AuthenticationManager manager){this.manager=manager;}
 @PostMapping("/login")
 public String login(@RequestBody LoginRequest r){
  manager.authenticate(new UsernamePasswordAuthenticationToken(r.username(),r.password()));
  return "Login successful";
 }
 public record LoginRequest(String username,String password){}
}
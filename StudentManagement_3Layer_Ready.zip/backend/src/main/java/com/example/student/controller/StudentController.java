package com.example.student.controller;
import com.example.student.model.Student;
import com.example.student.service.StudentService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api/students")
public class StudentController {
 private final StudentService service;
 public StudentController(StudentService service){this.service=service;}
 @GetMapping public List<Student> all(){return service.getAll();}
 @PostMapping public String create(@Valid @RequestBody Student s){service.create(s);return "Student added successfully";}
 @PutMapping("/{id}") public String update(@PathVariable Long id,@Valid @RequestBody Student s){service.update(id,s);return "Student updated successfully";}
 @DeleteMapping("/{id}") public String delete(@PathVariable Long id){service.delete(id);return "Student deleted successfully";}
}
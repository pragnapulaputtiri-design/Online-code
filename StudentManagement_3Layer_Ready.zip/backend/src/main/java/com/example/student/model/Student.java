package com.example.student.model;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
public class Student {
 private Long id;
 @NotBlank private String name;
 @NotBlank @Email private String email;
 @NotBlank private String course;
 private String phone;
 public Student(){}
 public Student(Long id,String name,String email,String course,String phone){this.id=id;this.name=name;this.email=email;this.course=course;this.phone=phone;}
 public Long getId(){return id;} public void setId(Long id){this.id=id;}
 public String getName(){return name;} public void setName(String v){name=v;}
 public String getEmail(){return email;} public void setEmail(String v){email=v;}
 public String getCourse(){return course;} public void setCourse(String v){course=v;}
 public String getPhone(){return phone;} public void setPhone(String v){phone=v;}
}
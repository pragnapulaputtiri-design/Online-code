package com.example.student.service;
import com.example.student.model.Student;
import com.example.student.repository.StudentRepository;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class StudentService {
 private final StudentRepository repo;
 public StudentService(StudentRepository repo){this.repo=repo;}
 public List<Student> getAll(){return repo.findAll();}
 public void create(Student s){repo.save(s);}
 public void update(Long id,Student s){repo.update(id,s);}
 public void delete(Long id){repo.delete(id);}
}
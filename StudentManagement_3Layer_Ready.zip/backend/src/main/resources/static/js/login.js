async function login(){
 const username=document.getElementById('username').value.trim(),password=document.getElementById('password').value;
 const r=await fetch('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,password})});
 const t=await r.text();document.getElementById('msg').textContent=t;
 if(r.ok) location.href='/dashboard.html';
}
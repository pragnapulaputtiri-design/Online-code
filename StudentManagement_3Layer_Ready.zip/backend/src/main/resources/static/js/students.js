let editId=null;
async function loadStudents(){
 const r=await fetch('/api/students'); if(!r.ok){location.href='/login.html';return;}
 const data=await r.json(), q=document.getElementById('search').value.toLowerCase();
 const filtered=data.filter(s=>(s.name+' '+s.email+' '+s.course).toLowerCase().includes(q));
 document.getElementById('rows').innerHTML=filtered.map(s=>`<tr>
 <td>${s.id}</td><td>${esc(s.name)}</td><td>${esc(s.email)}</td><td>${esc(s.course)}</td><td>${esc(s.phone||'')}</td>
 <td><button class="btn edit" onclick='editStudent(${JSON.stringify(s)})'>Edit</button>
 <button class="btn danger" onclick="deleteStudent(${s.id})">Delete</button></td></tr>`).join('');
}
function esc(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function editStudent(s){editId=s.id;name.value=s.name;email.value=s.email;course.value=s.course;phone.value=s.phone||'';msg.textContent='Editing student #'+s.id;}
async function saveStudent(){
 const body={name:name.value.trim(),email:email.value.trim(),course:course.value.trim(),phone:phone.value.trim()};
 if(!body.name||!body.email||!body.course){msg.textContent='Name, email and course are required.';return;}
 const url=editId?'/api/students/'+editId:'/api/students';
 const r=await fetch(url,{method:editId?'PUT':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
 msg.textContent=await r.text();editId=null;document.querySelectorAll('.grid input').forEach(x=>x.value='');loadStudents();
}
async function deleteStudent(id){if(!confirm('Delete this student?'))return;await fetch('/api/students/'+id,{method:'DELETE'});loadStudents();}
loadStudents();